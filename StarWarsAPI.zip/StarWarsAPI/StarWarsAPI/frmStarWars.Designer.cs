﻿namespace StarWarsAPI
{
    partial class frmStarWars
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            tabControl1 = new TabControl();
            tbpPlanet = new TabPage();
            txbPlanet = new TextBox();
            lblPlanetClimate = new Label();
            lblPlanetOrbitalPeriod = new Label();
            lblPlanetPopulation = new Label();
            lblPlanetSurfaceWater = new Label();
            lblPlanetTerrain = new Label();
            lblPlanetGravity = new Label();
            lblPlanetDiameter = new Label();
            lblPlanetRotationPeriod = new Label();
            lblPlanetName = new Label();
            btnPlanets = new Button();
            lblPlanetsTitle = new Label();
            tbpPerson = new TabPage();
            txbPerson = new TextBox();
            lblPersonHomeworld = new Label();
            lblPersonGender = new Label();
            lblPersonBirthYear = new Label();
            lblPersonEyeColor = new Label();
            lblPersonSkinColor = new Label();
            lblPersonHairColor = new Label();
            lblPersonMass = new Label();
            lblPersonHeight = new Label();
            lblPersonName = new Label();
            btnPeople = new Button();
            lblPeopleTitle = new Label();
            tbpSpecies = new TabPage();
            ltbSpecies = new ListBox();
            btnSpecies = new Button();
            lblSpeciesTitle = new Label();
            lblPersonStarships = new Label();
            tabControl1.SuspendLayout();
            tbpPlanet.SuspendLayout();
            tbpPerson.SuspendLayout();
            tbpSpecies.SuspendLayout();
            SuspendLayout();
            // 
            // tabControl1
            // 
            tabControl1.Controls.Add(tbpPlanet);
            tabControl1.Controls.Add(tbpPerson);
            tabControl1.Controls.Add(tbpSpecies);
            tabControl1.Location = new Point(0, 0);
            tabControl1.Name = "tabControl1";
            tabControl1.SelectedIndex = 0;
            tabControl1.Size = new Size(534, 314);
            tabControl1.TabIndex = 0;
            // 
            // tbpPlanet
            // 
            tbpPlanet.Controls.Add(txbPlanet);
            tbpPlanet.Controls.Add(lblPlanetClimate);
            tbpPlanet.Controls.Add(lblPlanetOrbitalPeriod);
            tbpPlanet.Controls.Add(lblPlanetPopulation);
            tbpPlanet.Controls.Add(lblPlanetSurfaceWater);
            tbpPlanet.Controls.Add(lblPlanetTerrain);
            tbpPlanet.Controls.Add(lblPlanetGravity);
            tbpPlanet.Controls.Add(lblPlanetDiameter);
            tbpPlanet.Controls.Add(lblPlanetRotationPeriod);
            tbpPlanet.Controls.Add(lblPlanetName);
            tbpPlanet.Controls.Add(btnPlanets);
            tbpPlanet.Controls.Add(lblPlanetsTitle);
            tbpPlanet.Location = new Point(4, 24);
            tbpPlanet.Name = "tbpPlanet";
            tbpPlanet.Padding = new Padding(3);
            tbpPlanet.Size = new Size(526, 261);
            tbpPlanet.TabIndex = 0;
            tbpPlanet.Text = "Planets";
            tbpPlanet.UseVisualStyleBackColor = true;
            // 
            // txbPlanet
            // 
            txbPlanet.Location = new Point(13, 41);
            txbPlanet.Name = "txbPlanet";
            txbPlanet.Size = new Size(135, 23);
            txbPlanet.TabIndex = 11;
            // 
            // lblPlanetClimate
            // 
            lblPlanetClimate.AutoSize = true;
            lblPlanetClimate.Location = new Point(189, 128);
            lblPlanetClimate.Name = "lblPlanetClimate";
            lblPlanetClimate.Size = new Size(76, 15);
            lblPlanetClimate.TabIndex = 10;
            lblPlanetClimate.Text = "Climate: N/A";
            // 
            // lblPlanetOrbitalPeriod
            // 
            lblPlanetOrbitalPeriod.AutoSize = true;
            lblPlanetOrbitalPeriod.Location = new Point(189, 71);
            lblPlanetOrbitalPeriod.Name = "lblPlanetOrbitalPeriod";
            lblPlanetOrbitalPeriod.Size = new Size(108, 15);
            lblPlanetOrbitalPeriod.TabIndex = 9;
            lblPlanetOrbitalPeriod.Text = "Orbital Period: N/A";
            // 
            // lblPlanetPopulation
            // 
            lblPlanetPopulation.AutoSize = true;
            lblPlanetPopulation.Location = new Point(189, 239);
            lblPlanetPopulation.Name = "lblPlanetPopulation";
            lblPlanetPopulation.Size = new Size(93, 15);
            lblPlanetPopulation.TabIndex = 8;
            lblPlanetPopulation.Text = "Population: N/A";
            // 
            // lblPlanetSurfaceWater
            // 
            lblPlanetSurfaceWater.AutoSize = true;
            lblPlanetSurfaceWater.Location = new Point(189, 213);
            lblPlanetSurfaceWater.Name = "lblPlanetSurfaceWater";
            lblPlanetSurfaceWater.Size = new Size(108, 15);
            lblPlanetSurfaceWater.TabIndex = 7;
            lblPlanetSurfaceWater.Text = "Surface Water: N/A";
            // 
            // lblPlanetTerrain
            // 
            lblPlanetTerrain.AutoSize = true;
            lblPlanetTerrain.Location = new Point(189, 184);
            lblPlanetTerrain.Name = "lblPlanetTerrain";
            lblPlanetTerrain.Size = new Size(70, 15);
            lblPlanetTerrain.TabIndex = 6;
            lblPlanetTerrain.Text = "Terrain: N/A";
            // 
            // lblPlanetGravity
            // 
            lblPlanetGravity.AutoSize = true;
            lblPlanetGravity.Location = new Point(189, 155);
            lblPlanetGravity.Name = "lblPlanetGravity";
            lblPlanetGravity.Size = new Size(72, 15);
            lblPlanetGravity.TabIndex = 5;
            lblPlanetGravity.Text = "Gravity: N/A";
            // 
            // lblPlanetDiameter
            // 
            lblPlanetDiameter.AutoSize = true;
            lblPlanetDiameter.Location = new Point(189, 98);
            lblPlanetDiameter.Name = "lblPlanetDiameter";
            lblPlanetDiameter.Size = new Size(83, 15);
            lblPlanetDiameter.TabIndex = 4;
            lblPlanetDiameter.Text = "Diameter: N/A";
            // 
            // lblPlanetRotationPeriod
            // 
            lblPlanetRotationPeriod.AutoSize = true;
            lblPlanetRotationPeriod.Location = new Point(189, 41);
            lblPlanetRotationPeriod.Name = "lblPlanetRotationPeriod";
            lblPlanetRotationPeriod.Size = new Size(117, 15);
            lblPlanetRotationPeriod.TabIndex = 3;
            lblPlanetRotationPeriod.Text = "Rotation Period: N/A";
            // 
            // lblPlanetName
            // 
            lblPlanetName.AutoSize = true;
            lblPlanetName.Location = new Point(189, 12);
            lblPlanetName.Name = "lblPlanetName";
            lblPlanetName.Size = new Size(67, 15);
            lblPlanetName.TabIndex = 2;
            lblPlanetName.Text = "Name: N/A";
            // 
            // btnPlanets
            // 
            btnPlanets.Location = new Point(13, 78);
            btnPlanets.Name = "btnPlanets";
            btnPlanets.Size = new Size(135, 23);
            btnPlanets.TabIndex = 1;
            btnPlanets.Text = "Fetch Planet";
            btnPlanets.UseVisualStyleBackColor = true;
            btnPlanets.Click += btnPlanets_Click;
            // 
            // lblPlanetsTitle
            // 
            lblPlanetsTitle.AutoSize = true;
            lblPlanetsTitle.Location = new Point(13, 12);
            lblPlanetsTitle.Name = "lblPlanetsTitle";
            lblPlanetsTitle.Size = new Size(135, 15);
            lblPlanetsTitle.TabIndex = 0;
            lblPlanetsTitle.Text = "Search a planet by its ID:";
            // 
            // tbpPerson
            // 
            tbpPerson.Controls.Add(lblPersonStarships);
            tbpPerson.Controls.Add(txbPerson);
            tbpPerson.Controls.Add(lblPersonHomeworld);
            tbpPerson.Controls.Add(lblPersonGender);
            tbpPerson.Controls.Add(lblPersonBirthYear);
            tbpPerson.Controls.Add(lblPersonEyeColor);
            tbpPerson.Controls.Add(lblPersonSkinColor);
            tbpPerson.Controls.Add(lblPersonHairColor);
            tbpPerson.Controls.Add(lblPersonMass);
            tbpPerson.Controls.Add(lblPersonHeight);
            tbpPerson.Controls.Add(lblPersonName);
            tbpPerson.Controls.Add(btnPeople);
            tbpPerson.Controls.Add(lblPeopleTitle);
            tbpPerson.Location = new Point(4, 24);
            tbpPerson.Name = "tbpPerson";
            tbpPerson.Padding = new Padding(3);
            tbpPerson.Size = new Size(526, 286);
            tbpPerson.TabIndex = 1;
            tbpPerson.Text = "People";
            tbpPerson.UseVisualStyleBackColor = true;
            // 
            // txbPerson
            // 
            txbPerson.Location = new Point(11, 41);
            txbPerson.Name = "txbPerson";
            txbPerson.Size = new Size(150, 23);
            txbPerson.TabIndex = 11;
            // 
            // lblPersonHomeworld
            // 
            lblPersonHomeworld.AutoSize = true;
            lblPersonHomeworld.Location = new Point(188, 238);
            lblPersonHomeworld.Name = "lblPersonHomeworld";
            lblPersonHomeworld.Size = new Size(98, 15);
            lblPersonHomeworld.TabIndex = 10;
            lblPersonHomeworld.Text = "Homeworld: N/A";
            // 
            // lblPersonGender
            // 
            lblPersonGender.AutoSize = true;
            lblPersonGender.Location = new Point(188, 210);
            lblPersonGender.Name = "lblPersonGender";
            lblPersonGender.Size = new Size(73, 15);
            lblPersonGender.TabIndex = 9;
            lblPersonGender.Text = "Gender: N/A";
            // 
            // lblPersonBirthYear
            // 
            lblPersonBirthYear.AutoSize = true;
            lblPersonBirthYear.Location = new Point(188, 181);
            lblPersonBirthYear.Name = "lblPersonBirthYear";
            lblPersonBirthYear.Size = new Size(85, 15);
            lblPersonBirthYear.TabIndex = 8;
            lblPersonBirthYear.Text = "Birth Year: N/A";
            // 
            // lblPersonEyeColor
            // 
            lblPersonEyeColor.AutoSize = true;
            lblPersonEyeColor.Location = new Point(188, 155);
            lblPersonEyeColor.Name = "lblPersonEyeColor";
            lblPersonEyeColor.Size = new Size(85, 15);
            lblPersonEyeColor.TabIndex = 7;
            lblPersonEyeColor.Text = "Eye Color: N/A";
            // 
            // lblPersonSkinColor
            // 
            lblPersonSkinColor.AutoSize = true;
            lblPersonSkinColor.Location = new Point(188, 126);
            lblPersonSkinColor.Name = "lblPersonSkinColor";
            lblPersonSkinColor.Size = new Size(89, 15);
            lblPersonSkinColor.TabIndex = 6;
            lblPersonSkinColor.Text = "Skin Color: N/A";
            // 
            // lblPersonHairColor
            // 
            lblPersonHairColor.AutoSize = true;
            lblPersonHairColor.Location = new Point(188, 98);
            lblPersonHairColor.Name = "lblPersonHairColor";
            lblPersonHairColor.Size = new Size(89, 15);
            lblPersonHairColor.TabIndex = 5;
            lblPersonHairColor.Text = "Hair Color: N/A";
            // 
            // lblPersonMass
            // 
            lblPersonMass.AutoSize = true;
            lblPersonMass.Location = new Point(188, 70);
            lblPersonMass.Name = "lblPersonMass";
            lblPersonMass.Size = new Size(62, 15);
            lblPersonMass.TabIndex = 4;
            lblPersonMass.Text = "Mass: N/A";
            // 
            // lblPersonHeight
            // 
            lblPersonHeight.AutoSize = true;
            lblPersonHeight.Location = new Point(188, 41);
            lblPersonHeight.Name = "lblPersonHeight";
            lblPersonHeight.Size = new Size(71, 15);
            lblPersonHeight.TabIndex = 3;
            lblPersonHeight.Text = "Height: N/A";
            // 
            // lblPersonName
            // 
            lblPersonName.AutoSize = true;
            lblPersonName.Location = new Point(188, 12);
            lblPersonName.Name = "lblPersonName";
            lblPersonName.Size = new Size(67, 15);
            lblPersonName.TabIndex = 2;
            lblPersonName.Text = "Name: N/A";
            // 
            // btnPeople
            // 
            btnPeople.Location = new Point(11, 80);
            btnPeople.Name = "btnPeople";
            btnPeople.Size = new Size(150, 23);
            btnPeople.TabIndex = 1;
            btnPeople.Text = "Fetch Person";
            btnPeople.UseVisualStyleBackColor = true;
            btnPeople.Click += btnPeople_Click;
            // 
            // lblPeopleTitle
            // 
            lblPeopleTitle.AutoSize = true;
            lblPeopleTitle.Location = new Point(11, 12);
            lblPeopleTitle.Name = "lblPeopleTitle";
            lblPeopleTitle.Size = new Size(150, 15);
            lblPeopleTitle.TabIndex = 0;
            lblPeopleTitle.Text = "Search a person by their ID:";
            // 
            // tbpSpecies
            // 
            tbpSpecies.Controls.Add(ltbSpecies);
            tbpSpecies.Controls.Add(btnSpecies);
            tbpSpecies.Controls.Add(lblSpeciesTitle);
            tbpSpecies.Location = new Point(4, 24);
            tbpSpecies.Name = "tbpSpecies";
            tbpSpecies.Padding = new Padding(3);
            tbpSpecies.Size = new Size(526, 286);
            tbpSpecies.TabIndex = 2;
            tbpSpecies.Text = "Species";
            tbpSpecies.UseVisualStyleBackColor = true;
            // 
            // ltbSpecies
            // 
            ltbSpecies.FormattingEnabled = true;
            ltbSpecies.ItemHeight = 15;
            ltbSpecies.Location = new Point(169, 11);
            ltbSpecies.Name = "ltbSpecies";
            ltbSpecies.Size = new Size(353, 274);
            ltbSpecies.TabIndex = 2;
            // 
            // btnSpecies
            // 
            btnSpecies.Location = new Point(11, 31);
            btnSpecies.Name = "btnSpecies";
            btnSpecies.Size = new Size(133, 23);
            btnSpecies.TabIndex = 1;
            btnSpecies.Text = "All Species";
            btnSpecies.UseVisualStyleBackColor = true;
            btnSpecies.Click += btnSpecies_Click;
            // 
            // lblSpeciesTitle
            // 
            lblSpeciesTitle.AutoSize = true;
            lblSpeciesTitle.Location = new Point(11, 11);
            lblSpeciesTitle.Name = "lblSpeciesTitle";
            lblSpeciesTitle.Size = new Size(133, 15);
            lblSpeciesTitle.TabIndex = 0;
            lblSpeciesTitle.Text = "Click to request species:";
            // 
            // lblPersonStarships
            // 
            lblPersonStarships.AutoSize = true;
            lblPersonStarships.Location = new Point(188, 263);
            lblPersonStarships.Name = "lblPersonStarships";
            lblPersonStarships.Size = new Size(82, 15);
            lblPersonStarships.TabIndex = 12;
            lblPersonStarships.Text = "Starships: N/A";
            // 
            // frmStarWars
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(532, 311);
            Controls.Add(tabControl1);
            Name = "frmStarWars";
            Text = "Menu";
            tabControl1.ResumeLayout(false);
            tbpPlanet.ResumeLayout(false);
            tbpPlanet.PerformLayout();
            tbpPerson.ResumeLayout(false);
            tbpPerson.PerformLayout();
            tbpSpecies.ResumeLayout(false);
            tbpSpecies.PerformLayout();
            ResumeLayout(false);
        }

        #endregion

        private TabControl tabControl1;
        private TabPage tbpPlanet;
        private Label lblPlanetClimate;
        private Label lblPlanetOrbitalPeriod;
        private Label lblPlanetPopulation;
        private Label lblPlanetSurfaceWater;
        private Label lblPlanetTerrain;
        private Label lblPlanetGravity;
        private Label lblPlanetDiameter;
        private Label lblPlanetRotationPeriod;
        private Label lblPlanetName;
        private Button btnPlanets;
        private Label lblPlanetsTitle;
        private TabPage tbpPerson;
        private Label lblPersonHomeworld;
        private Label lblPersonGender;
        private Label lblPersonBirthYear;
        private Label lblPersonEyeColor;
        private Label lblPersonSkinColor;
        private Label lblPersonHairColor;
        private Label lblPersonMass;
        private Label lblPersonHeight;
        private Label lblPersonName;
        private Button btnPeople;
        private Label lblPeopleTitle;
        private TabPage tbpSpecies;
        private ListBox ltbSpecies;
        private Button btnSpecies;
        private Label lblSpeciesTitle;
        private TextBox txbPlanet;
        private TextBox txbPerson;
        private Label lblPersonStarships;
    }
}