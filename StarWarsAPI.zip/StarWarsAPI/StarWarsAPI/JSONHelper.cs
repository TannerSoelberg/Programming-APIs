﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.Json.Serialization;
using Newtonsoft.Json;
using System.Net.Http;
using System.Threading.Tasks;
using StarWarsAPI.Objects;

namespace StarWarsAPI
{
    public class JSONHelper
    {
        static readonly HttpClient client = new HttpClient();

        /// <summary>
        /// This function fetches a planet's data (and converts it into a "Planet" object) from a given ID.
        /// </summary>
        /// <param name="PlanetID"> This is a string ID. </param>
        /// <returns> A planet object. </returns>
        public static async Task<Planet> GetPlanet(string PlanetID)
        {
            Planet myDeserializedClass = new Planet();
            try
            {
                using HttpResponseMessage response = await client.GetAsync("https://swapi.dev/api/planets/" + PlanetID + "/");
                response.EnsureSuccessStatusCode();
                string responseBody = await response.Content.ReadAsStringAsync();
                // Above three lines can be replaced with new helper method below
                // string responseBody = await client.GetStringAsync(uri);

                myDeserializedClass = JsonConvert.DeserializeObject<Planet>(responseBody);
            }
            catch (HttpRequestException e)
            {
                Console.WriteLine("\nException Caught!");
                Console.WriteLine("Message :{0} ", e.Message);
            }
            return myDeserializedClass;
        }

        /// <summary>
        /// This function fetches a person's data (and converts it into a "Person" object) from a given ID.
        /// </summary>
        /// <param name="PersonID"> This is a string ID. </param>
        /// <returns> A planet object. </returns>
        public static async Task<Person> GetPerson(string PersonID)
        {
            Person myDeserializedClass = new Person();
            try
            {
                using HttpResponseMessage response = await client.GetAsync("https://swapi.dev/api/people/" + PersonID + "/");
                response.EnsureSuccessStatusCode();
                string responseBody = await response.Content.ReadAsStringAsync();
                // Above three lines can be replaced with new helper method below
                // string responseBody = await client.GetStringAsync(uri);

                myDeserializedClass = JsonConvert.DeserializeObject<Person>(responseBody);
            }
            catch (HttpRequestException e)
            {
                Console.WriteLine("\nException Caught!");
                Console.WriteLine("Message :{0} ", e.Message);
            }
            return myDeserializedClass;
        }

        /// <summary>
        /// This function returns a starship's data (and converts it into a "Starship" object) from a given ID.
        /// </summary>
        /// <param name="StarshipID"> This is a string ID. </param>
        /// <returns> A starship object. </returns>
        public static async Task<Starship> GetStarship(string StarshipID)
        {
            Starship myDeserializedClass = new Starship();
            try
            {
                using HttpResponseMessage response = await client.GetAsync("https://swapi.dev/api/starships/" + StarshipID + "/");
                response.EnsureSuccessStatusCode();
                string responseBody = await response.Content.ReadAsStringAsync();
                // Above three lines can be replaced with new helper method below
                // string responseBody = await client.GetStringAsync(uri);

                myDeserializedClass = JsonConvert.DeserializeObject<Starship>(responseBody);
            }
            catch (HttpRequestException e)
            {
                Console.WriteLine("\nException Caught!");
                Console.WriteLine("Message :{0} ", e.Message);
            }
            return myDeserializedClass;
        }

        /// <summary>
        /// This function retrieves a list of species objects.
        /// </summary>
        /// <returns> A list of species. </returns>
        public static async Task<AllSpecies> GetAllSpecies()
        {
            AllSpecies myDeserializedClass = new AllSpecies();
            try
            {
                using HttpResponseMessage response = await client.GetAsync("https://swapi.dev/api/species/");
                response.EnsureSuccessStatusCode();
                string responseBody = await response.Content.ReadAsStringAsync();
                // Above three lines can be replaced with new helper method below
                // string responseBody = await client.GetStringAsync(uri);

                myDeserializedClass = JsonConvert.DeserializeObject<AllSpecies>(responseBody);
            }
            catch (HttpRequestException e)
            {
                Console.WriteLine("\nException Caught!");
                Console.WriteLine("Message :{0} ", e.Message);
            }
            return myDeserializedClass;
        }
    }
}
