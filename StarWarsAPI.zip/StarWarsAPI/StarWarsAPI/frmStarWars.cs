﻿using StarWarsAPI.Objects;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace StarWarsAPI
{
    public partial class frmStarWars : Form
    {
        public frmStarWars()
        {
            InitializeComponent();
        }

        private async void btnPlanets_Click(object sender, EventArgs e)
        {
            Planet t = await JSONHelper.GetPlanet(txbPlanet.Text);

            if (t != null)
            {
                lblPlanetName.Text = "Name: " + t.name;
                lblPlanetRotationPeriod.Text = "Rotation Period: " + t.rotation_period;
                lblPlanetOrbitalPeriod.Text = "Orbital Period: " + t.orbital_period;
                lblPlanetDiameter.Text = "Diameter: " + t.diameter;
                lblPlanetClimate.Text = "Climate: " + t.climate;
                lblPlanetGravity.Text = "Gravity: " + t.gravity;
                lblPlanetTerrain.Text = "Terrain: " + t.terrain;
                lblPlanetSurfaceWater.Text = "Surface Water: " + t.surface_water;
                lblPlanetPopulation.Text = "Population: " + t.population;
            }
        }

        private async void btnPeople_Click(object sender, EventArgs e)
        {
            Person p = await JSONHelper.GetPerson(txbPerson.Text);

            if (p != null)
            {
                string[] worldNum = p.homeworld.Split('/');
                Planet t = await JSONHelper.GetPlanet(worldNum[5]);

                string allStarships = "";
                foreach (var item in p.starships)
                {

                    string[] starshipNum = item.ToString().Split('/');
                    Starship ss = await JSONHelper.GetStarship(starshipNum[5]);

                    allStarships += ss.name + ", ";
                }

                lblPersonStarships.Text = "Starships: " + allStarships;
                lblPersonHomeworld.Text = "Homeworld: " + t.name;
                lblPersonName.Text = "Name: " + p.name;
                lblPersonHeight.Text = "Height: " + p.height;
                lblPersonMass.Text = "Mass: " + p.mass;
                lblPersonHairColor.Text = "Hair Color: " + p.hair_color;
                lblPersonSkinColor.Text = "Skin Color: " + p.skin_color;
                lblPersonEyeColor.Text = "Eye Color: " + p.eye_color;
                lblPersonBirthYear.Text = "Birth Year: " + p.birth_year;
                lblPersonGender.Text = "Gender: " + p.gender;
            }
        }

        private async void btnSpecies_Click(object sender, EventArgs e)
        {
            ltbSpecies.Items.Clear();

            ltbSpecies.Items.Add("Loading...");

            AllSpecies s = await JSONHelper.GetAllSpecies();

            ltbSpecies.Items.Clear();

            if (s != null && s.results != null)
            {
                foreach (var item in s.results)
                {
                    Planet t = new Planet();

                    if (item.homeworld != null)
                    {
                        string[] worldNum = item.homeworld.Split('/');
                        t = await JSONHelper.GetPlanet(worldNum[5]);
                    }

                    ltbSpecies.Items.Add("----   " + item.name + "   ----");
                    ltbSpecies.Items.Add("Classification: " + item.classification);
                    ltbSpecies.Items.Add("Designation: " + item.designation);
                    ltbSpecies.Items.Add("Average Height: " + item.average_height);
                    ltbSpecies.Items.Add("Skin Colors: " + item.skin_colors);
                    ltbSpecies.Items.Add("Hair Colors: " + item.hair_colors);
                    ltbSpecies.Items.Add("Eye Colors: " + item.eye_colors);
                    ltbSpecies.Items.Add("Average Lifespan: " + item.average_lifespan);

                    if (t != null)
                    {
                        ltbSpecies.Items.Add("Homeworld: " + t.name);
                    }
                    else
                    {
                        ltbSpecies.Items.Add("Homeworld: n/a");
                    }

                    ltbSpecies.Items.Add("Language: " + item.language);
                    ltbSpecies.Items.Add("");
                }
            }
        }
    }
}
