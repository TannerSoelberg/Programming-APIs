using PokeAPI;

namespace PokemonAPI
{
    public partial class frmPokemon : Form
    {
        public frmPokemon()
        {
            InitializeComponent();
        }

        /// <summary>
        /// This function searches for a pokemon (as directed by the user) and returns a Pokemon object.
        /// It then sets the GUI text and sets it according to the pokemon attributes.
        /// </summary>
        public async void GetSpecies()
        {
            try
            {
                PokemonSpecies p = await DataFetcher.GetNamedApiObject<PokemonSpecies>(txbSpecies.Text);

                lblSpecies.Text = "Species: " + p.Name;
                lblHappiness.Text = "Base Happines: " + p.BaseHappiness.ToString();
                lblCapture.Text = "Capture Rate: " + p.CaptureRate.ToString();
                lblHabitat.Text = "Habitat: " + p.Habitat.Name;
                lblGrowth.Text = "Growth Rate: " + p.GrowthRate.Name;
                lblFlavor.Text = "Flavor: " + p.FlavorTexts[0].FlavorText;
                lblEgg.Text = "Egg Group: " + p.EggGroups[0].Name;
            }
            catch 
            {
                lblSpecies.Text = "Species: N/A";
                lblHappiness.Text = "Base Happines: N/A";
                lblCapture.Text = "Capture Rate: N/A";
                lblHabitat.Text = "Habitat: N/A";
                lblGrowth.Text = "Growth Rate: N/A";
                lblFlavor.Text = "Flavor: N/A";
                lblEgg.Text = "Egg Group: N/A";
            }
        }

        private void btnSearch_Click(object sender, EventArgs e)
        {
            GetSpecies();
        }
    }
}