﻿namespace PokemonAPI
{
    partial class frmPokemon
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            lblInstructions = new Label();
            lblSpecies = new Label();
            lblHappiness = new Label();
            lblHabitat = new Label();
            lblGrowth = new Label();
            lblFlavor = new Label();
            lblEgg = new Label();
            btnSearch = new Button();
            txbSpecies = new TextBox();
            lblCapture = new Label();
            SuspendLayout();
            // 
            // lblInstructions
            // 
            lblInstructions.AutoSize = true;
            lblInstructions.Location = new Point(12, 9);
            lblInstructions.Name = "lblInstructions";
            lblInstructions.Size = new Size(100, 15);
            lblInstructions.TabIndex = 0;
            lblInstructions.Text = "Enter a Pokemon:";
            // 
            // lblSpecies
            // 
            lblSpecies.AutoSize = true;
            lblSpecies.Location = new Point(12, 94);
            lblSpecies.Name = "lblSpecies";
            lblSpecies.Size = new Size(74, 15);
            lblSpecies.TabIndex = 1;
            lblSpecies.Text = "Species: N/A";
            // 
            // lblHappiness
            // 
            lblHappiness.AutoSize = true;
            lblHappiness.Location = new Point(12, 145);
            lblHappiness.Name = "lblHappiness";
            lblHappiness.Size = new Size(117, 15);
            lblHappiness.TabIndex = 2;
            lblHappiness.Text = "Base Happiness: N/A";
            // 
            // lblHabitat
            // 
            lblHabitat.AutoSize = true;
            lblHabitat.Location = new Point(12, 243);
            lblHabitat.Name = "lblHabitat";
            lblHabitat.Size = new Size(74, 15);
            lblHabitat.TabIndex = 3;
            lblHabitat.Text = "Habitat: N/A";
            // 
            // lblGrowth
            // 
            lblGrowth.AutoSize = true;
            lblGrowth.Location = new Point(12, 289);
            lblGrowth.Name = "lblGrowth";
            lblGrowth.Size = new Size(100, 15);
            lblGrowth.TabIndex = 4;
            lblGrowth.Text = "Growth Rate: N/A";
            // 
            // lblFlavor
            // 
            lblFlavor.AutoSize = true;
            lblFlavor.Location = new Point(226, 94);
            lblFlavor.Name = "lblFlavor";
            lblFlavor.Size = new Size(67, 15);
            lblFlavor.TabIndex = 5;
            lblFlavor.Text = "Flavor: N/A";
            // 
            // lblEgg
            // 
            lblEgg.AutoSize = true;
            lblEgg.Location = new Point(12, 336);
            lblEgg.Name = "lblEgg";
            lblEgg.Size = new Size(91, 15);
            lblEgg.TabIndex = 6;
            lblEgg.Text = "Egg Group: N/A";
            // 
            // btnSearch
            // 
            btnSearch.BackColor = Color.LightSteelBlue;
            btnSearch.Location = new Point(12, 58);
            btnSearch.Name = "btnSearch";
            btnSearch.Size = new Size(201, 23);
            btnSearch.TabIndex = 7;
            btnSearch.Text = "Search";
            btnSearch.UseVisualStyleBackColor = false;
            btnSearch.Click += btnSearch_Click;
            // 
            // txbSpecies
            // 
            txbSpecies.Location = new Point(12, 27);
            txbSpecies.Name = "txbSpecies";
            txbSpecies.Size = new Size(201, 23);
            txbSpecies.TabIndex = 8;
            // 
            // lblCapture
            // 
            lblCapture.AutoSize = true;
            lblCapture.Location = new Point(12, 195);
            lblCapture.Name = "lblCapture";
            lblCapture.Size = new Size(103, 15);
            lblCapture.TabIndex = 9;
            lblCapture.Text = "Capture Rate: N/A";
            // 
            // frmPokemon
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = SystemColors.ActiveCaption;
            ClientSize = new Size(564, 522);
            Controls.Add(lblCapture);
            Controls.Add(txbSpecies);
            Controls.Add(btnSearch);
            Controls.Add(lblEgg);
            Controls.Add(lblFlavor);
            Controls.Add(lblGrowth);
            Controls.Add(lblHabitat);
            Controls.Add(lblHappiness);
            Controls.Add(lblSpecies);
            Controls.Add(lblInstructions);
            Name = "frmPokemon";
            Text = "Pokemon Search";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label lblInstructions;
        private Label lblSpecies;
        private Label lblHappiness;
        private Label lblHabitat;
        private Label lblGrowth;
        private Label lblFlavor;
        private Label lblEgg;
        private Button btnSearch;
        private TextBox txbSpecies;
        private Label lblCapture;
    }
}